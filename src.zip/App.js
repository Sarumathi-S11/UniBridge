import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LaunchingPage from "./LaunchingPage";
import LoginPage from "./LoginPage";
import SignupPage from "./SignupPage";
function App() {

  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch("http://localhost:8080")   // NO localhost here
      .then(res => res.text())
      .then(data => setMessage(data))
      .catch(err => console.error("Error:", err));
  }, []);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<LaunchingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
      </Routes>
    </Router>
  );

}

export default App;