import React, { useState } from "react";
import axios from "axios";
import "./LoginPage.css";   // same style use pannalam

function SignupPage() {

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("STUDENT");

  const handleSignup = () => {
    axios.post("http://localhost:8080/register", {
      name,
      email,
      password,
      role
    })
    .then(res => alert(res.data))
    .catch(() => alert("Registration Failed"));
  };

  return (
    
    <div className="login-container">
      <div className="login-card">

        <h2>Register</h2>

        <input 
          type="text"
          placeholder="Enter Name"
          onChange={(e) => setName(e.target.value)}
        />

        <select onChange={(e) => setRole(e.target.value)}>
          <option value="STUDENT">Student</option>
          <option value="ADMIN">Admin</option>
        </select>

        <input 
          type="email"
          placeholder="Enter Email"
          onChange={(e) => setEmail(e.target.value)}
        />

        <input 
          type="password"
          placeholder="Enter Password"
          onChange={(e) => setPassword(e.target.value)}
        />

        <button onClick={handleSignup}>
          Register
        </button>

      </div>
    </div>
  );
}

export default SignupPage;