import React, { useState } from "react";
import axios from "axios";
import { FaGraduationCap } from "react-icons/fa";
import "./LoginPage.css";

function LoginPage() {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("STUDENT");

  const handleLogin = () => {
    axios.post("http://localhost:8080/login", {
      email,
      password,
      role
    })
    .then(res => alert(res.data))
    .catch(() => alert("Login Failed"));
  };

  return (
    <div className="login-container">

      {/* Top Left Logo */}
      <div className="top-logo">
        <FaGraduationCap className="logo-icon" />
        <span>UniBridge</span>
      </div>

      {/* Center Card */}
      <div className="login-card">

        <h2>{role === "ADMIN" ? "Admin Login" : "Student Login"}</h2>

        <select 
          className="role-select"
          value={role}
          onChange={(e) => setRole(e.target.value)}
        >
          <option value="STUDENT">Student</option>
          <option value="ADMIN">Admin</option>
        </select>

        <input 
          type="email"
          placeholder={`Enter ${role === "ADMIN" ? "Admin" : "Student"} Email`}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input 
          type="password"
          placeholder="Enter Password"
          onChange={(e) => setPassword(e.target.value)}
        />

        <button onClick={handleLogin}>
          Login
        </button>

      </div>

    </div>
  );
}

export default LoginPage;