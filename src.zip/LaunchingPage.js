import React from "react";
import "./LaunchingPage.css";
import { FaGraduationCap } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

function LaunchingPage() {
    const navigate = useNavigate();
  return (
    <div className="main-container">

      {/* Navbar */}
      <nav className="navbar">
        <div className="logo">
          <FaGraduationCap className="logo-icon" />
          <span>UniBridge</span>
        </div>
      </nav>

      {/* Center Section */}
      <div className="center-content">
        <h1>Welcome to UniBridge</h1>
        <p>Your Centralized Academic Resource Platform</p>

        <div className="button-group">
            <button className="login-btn" onClick={() => navigate("/login")}>
  Login
</button>
             <button className="signup-btn" onClick={() => navigate("/signup")}>Sign Up</button>
          
        </div>
      </div>

    </div>
  );
}

export default LaunchingPage;