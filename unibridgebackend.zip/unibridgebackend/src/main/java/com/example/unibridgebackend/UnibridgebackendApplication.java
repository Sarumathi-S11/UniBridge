package com.example.unibridgebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnibridgebackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnibridgebackendApplication.class, args);
	}

}
