package com.example.unibridgebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnibridgebackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
